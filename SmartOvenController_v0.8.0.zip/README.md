# 智能烤箱控制器 v0.7.8

## 项目概述
这是一个基于ESP8266的智能烤箱控制器，具有以下功能：
- 温度监测（MAX6675传感器）
- 加热控制（PWM输出）
- Web界面控制
- OTA固件升级
- 文件系统OTA升级
- WiFi配置
- 移动端适配

## 包含文件
1. `firmware.bin` - 设备固件（375,392字节）
2. `littlefs.bin` - 文件系统镜像（1,024,000字节）
3. `platformio.ini` - 构建配置文件
4. `BUILD_INSTRUCTIONS.md` - 构建说明

## 烧录说明
### 方法1: 使用PlatformIO命令行
```bash
# 烧录固件
pio run -t upload

# 烧录文件系统
pio run -t uploadfs
```

### 方法2: 使用esptool手动烧录
```bash
# 烧录固件 (地址: 0x00000)
esptool.exe --port COM11 write_flash 0x00000 firmware.bin

# 烧录文件系统 (地址: 0x300000)
esptool.exe --port COM11 write_flash 0x300000 littlefs.bin
```

## OTA升级
设备支持通过Web界面进行OTA升级：
1. 访问设备的Web界面
2. 进入OTA升级页面
3. 选择要上传的固件(.bin)或文件系统文件
4. 点击上传并等待设备重启

## 注意事项
1. 确保在platformio.ini中正确配置了串口端口
2. 烧录前请确保设备已正确连接并进入烧录模式
3. 文件系统地址(0x300000)必须与platformio.ini中的配置一致

## 技术规格
- 平台: ESP8266 (NodeMCU)
- 框架: Arduino
- 依赖库: ESP8266WiFi, ESP8266WebServer, LittleFS, DNSServer, MAX6675
- 内存使用: RAM 57.7%, Flash 35.5%